const state = {

    // server_domain: "http://localhost:3000",

    server_domain: "https://aflalo-teva.cs.bgu.ac.il/",
    

};

module.exports = state;