<template>
    <div id="content-container">

<h1 id="main-title">About us</h1>

<div class="about-section">
  <h2 id="section-title">Our Mission</h2>
  <p>Grandmas and Recipes is here to help you cook delicious meals with less stress and more joy. We offer recipes and cooking advice for home cooks, by home cooks. Helping create “kitchen wins” is what we’re all about.</p>
  <p>Grandmas and Recipes was founded in 2023 by Omer Aflalo and Teva Erez as a web development exercise. Today, Grandmas and Recipes has grown into a trusted resource for home cooks with more than 5,000 tested recipes, guides, and meal plans, drawing over 100 million readers each month from around the world. We’re supported by a diverse group of recipe developers, food writers, recipe and product testers, photographers, and other creative professionals.</p>
</div>

<div class="about-section">
  <h2 id="section-title">Our History</h2>
  <p><b-row><b-col><a href="https://web-development-environments-2023.github.io/212927719/">Omer Aflalo's tribute website</a><img src="../assets/aflalosWebsite.jpg"></b-col><b-col><a href="https://web-development-environments-2023.github.io/212416242/">Teva Erez's tribute website</a><br><img src="../assets/tevasWebsite.png"></b-col></b-row>
    <br><b-row><a href="https://web-development-environments-2023.github.io/assignment2-212416242_212927719_324126671/#">Our game's website</a><br><img src="../assets/chickenInvaders.png"></b-row>
</p>
</div>
 
<div class="about-section">
  <h2 id="section-title">Recipe Development & Testing</h2>
  <p>Our recipes primarily use fresh, unprocessed ingredients but we also believe there is a time and a place for canned, frozen, and other prepared ingredients. We believe in a diet that includes a wide variety of foods: real butter and cream, extra virgin olive oil, eggs, lots of fruits and vegetables, and protein from meat, fish, beans, and cheese. Plus cake for dessert.</p>
  <p>There are three things we think about when deciding if a recipe is good enough to go on Grandmas and Recipes:</p>
  <ol>
    <li>First, does it work? Recipes need to be easy to follow and provide reliable results, every time.</li>
    <li>Second, is it delicious? Does the dish make us smile inside and out? Do we want to eat the whole batch by ourselves?</li>
    <li>Third, is it worth the effort? Do we want to make it again (and again and again)?</li>
  </ol>
  <p>To make sure each of these standards is met, we start by working with expert recipe developers — people with the experience and knowledge to not only develop a good recipe in their own kitchens but to make sure that recipe works in yours. Next, we thoroughly review and edit every recipe in-house line by line. Finally, each new recipe is run by our team of recipe testers working in home kitchens with the same pots, pans, and tools that you use in yours. Only after all this is the recipe shared on Grandmas and Recipes.</p>
</div>
<p>Have feedback for us? don't feel free to contact us...</p>
</div>
</template>
<style>
#content-container {
      font-family: Arial, sans-serif;
      line-height: 1.6;
      margin: 5%;
      padding: 20px;
      background-color: #f9f9f9;
    }

    #main-title {
      color: #333;
      text-align: center;
      margin-bottom: 20px;
    }

    #section-title {
      color: #555;
      margin-top: 40px;
    }

    .about-section {
      background-color: #f5f5f5;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
      margin-bottom: 20px;
    }
img{
    width: 100%;
}
</style>